# q1t

I am a manager at a hip company. 

I made this when I was first programming. It's got a bunch of errors. 

The code is all there, more or less, just needs a couple fixes. 

Hopefully I can get a new employee of mine to fix the problems. 
